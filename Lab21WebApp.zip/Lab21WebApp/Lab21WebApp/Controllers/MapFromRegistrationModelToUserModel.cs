﻿using Lab21WebApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab21WebApp.Controllers
{
    public class MapFromRegistrationModelToUserModel : IMapFromRegistrationModelToUserModel
    {

        public UserViewModel Map(RegistrationViewModel model)
        {
            var userData = new UserViewModel();
            userData.Username = model.Username;
            userData.Email = model.Email;
            userData.Password = model.Password;
            userData.FavoriteBand = model.FavoriteBand;
            userData.DoSheGotTheBooty = model.DoSheGotTheBooty;
            userData.HowManyLayers = model.HowManyLayers;

            return userData;
        }
}   }  
