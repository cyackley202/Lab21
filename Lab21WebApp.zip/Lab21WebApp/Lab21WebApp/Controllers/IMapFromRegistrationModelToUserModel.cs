﻿using Lab21WebApp.Models;

namespace Lab21WebApp.Controllers
{
    public interface IMapFromRegistrationModelToUserModel
    {
        public UserViewModel Map(RegistrationViewModel model);
    }
      
    
}