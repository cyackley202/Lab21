﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lab21WebApp.Models
{
    public class RegistrationViewModel
    {
        public RegistrationViewModel()
        {
           
        }
        [Required]
        public string Username { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string FavoriteBand { get; set; }

        public int HowManyLayers { get; set; }

        public bool DoSheGotTheBooty { get; set; }
    }
}
